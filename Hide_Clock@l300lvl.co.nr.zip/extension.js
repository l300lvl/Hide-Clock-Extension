const Main = imports.ui.main.panel;

function init() {
}

function disable() {
    Main._dateMenu.actor.show();
}

function enable() {
    Main._dateMenu.actor.hide();
}
